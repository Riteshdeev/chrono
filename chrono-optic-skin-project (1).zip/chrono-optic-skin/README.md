# CHRONO-OPTIC // ARCHIVE-70 — Video.js v10 Skin Project

Created following the official [Video.js v10 Build Your Own Skin Guide](https://videojs.org/docs/framework/html/guides/build-your-own-skin).

## Project Structure
- `src/` holds the skin markup (`src/skin.html`), styles (`src/video-skin.css`), and element registrations (`src/player.ts`).
- `apps/preview/` is the interactive workbench that previews your skin across player sizes, aspect ratios, light/dark color schemes, RTL text direction, built-in locales, and Mux playback settings.

## Quickstart
```bash
pnpm install
pnpm dev
```

## Deploy Workbench
```bash
pnpm run deploy vercel
```
